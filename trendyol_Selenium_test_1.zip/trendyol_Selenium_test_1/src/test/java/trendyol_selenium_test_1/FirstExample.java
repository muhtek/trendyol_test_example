package trendyol_selenium_test_1;


import Resources.Resources;
import org.junit.Assert;
import org.junit.Test;
import Abstract.MainFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class FirstExample extends Resources {
    @Test
    public void firstExample() throws InterruptedException {

        Assert.assertEquals("En Trend Ürünler Türkiye'nin Online Alışveriş Sitesi Trendyol'da", driver.getTitle());
        System.out.println("Site başlığı kontrol edildi");
        xpath("/html[1]/body[1]/div[9]/div[1]/div[1]/a[1]").click();
        Actions action = new Actions(driver);
        WebElement element = xpath(menu);
        action.moveToElement(element).build().perform();
        Thread.sleep(2000);
        xpath(girisYap).click();
        id(username).sendKeys(eposta);
        id(pass).sendKeys(sifre);
        id(login).click();
        Thread.sleep(2000);
        xpath(tkadin).click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);
        xpath(terkek).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);
        xpath(tcocuk).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);
        xpath(tayakkabi).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);
        xpath(taksesuar).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);
        xpath(tkozmetik).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);
        xpath(tevyasam).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);
        xpath(telektronik).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);
        xpath(tsupermarket).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();
        Thread.sleep(5000);

        Thread.sleep(5000);
        xpath(terkek).click();
        js.executeScript("window.scrollBy(0,10000)");
        validateInvalidImages();

        xpath(randombutik).click();
        Thread.sleep(9000);
        xpath(randomUrun).click();
        Thread.sleep(5000);
        xpath(beden).click();
        Thread.sleep(2000);
        xpath(bedenSecim).click();
        Thread.sleep(2000);
        xpath(sepeteEkle).click();
        Thread.sleep(2000);

        WebElement element2 = xpath("/html[1]/body[1]/div[2]/div[1]/div[2]/div[3]/div[1]/div[1]/ul[1]/li[1]/div[1]");
        action.moveToElement(element2).build().perform();
        xpath("/html[1]/body[1]/div[2]/div[1]/div[2]/div[3]/div[1]/div[1]/ul[1]/li[1]/div[2]/span[2]/div[1]/div[5]/a[1]").click();



        /*xpath(logOut).click();*/

   /* String baySon1= xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[2]/div[1]/div[1]/form[1]/input[1]").getText();
    String bay1=xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[2]/section[2]/div[1]/div[1]/h1[1]").getAttribute("").toString();
    org.testng.Assert.assertEquals(baySon1,bay1);*/


    }

}
