package Resources;

import Abstract.MainFunctions;
import org.junit.Test;

public class Resources extends MainFunctions {

    static public String closePopUp="/html[1]/body[1]/div[9]/div[1]/div[1]/a[1]";
    static public String girisYap="/html[1]/body[1]/div[2]/div[1]/div[2]/div[3]/div[1]/div[1]/ul[1]/li[1]/div[2]/span[1]/div[1]/div[1]";
    static public String username ="email";
    static public String eposta="denemeadam987@gmail.com";
    static public String pass ="password";
    static public String sifre="571632Gs.";
    static public String login="loginSubmit";
    static public String tkadin="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[1]";
    static public String terkek="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[2]";
    static public String tcocuk="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[3]";
    static public String tayakkabi="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[4]";
    static public String taksesuar="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[5]";
    static public String tkozmetik="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[6]";
    static public String tevyasam="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[7]";
    static public String telektronik="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[8]";
    static public String tsupermarket="/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[9]";


    static public String randombutik="/html[1]/body[1]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/a[1]/div[1]";
    static public String randomUrun="/html[1]/body[1]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/ul[1]/li[52]/div[1]/a[1]/div[3]/div[1]/div[1]/img[1]";
    static public String beden="/html[1]/body[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[2]/div[2]/div[2]/div[1]/div[2]/span[1]/span[1]";
    static public String bedenSecim="/html[1]/body[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[2]/div[2]/div[2]/div[1]/div[3]/ul[1]/li[1]";
    static public String sepeteEkle="/html[1]/body[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[2]/div[3]/button[1]/div[1]";

    static public String menu="/html[1]/body[1]/div[2]/div[1]/div[2]/div[3]/div[1]/div[1]/ul[1]/li[1]/div[1]/i[1]";



}
